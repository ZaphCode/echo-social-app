/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update field
  collection.fields.addAt(7, new Field({
    "hidden": false,
    "id": "bool1383219978",
    "name": "client_agrees",
    "presentable": true,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  // update field
  collection.fields.addAt(8, new Field({
    "hidden": false,
    "id": "bool1357245225",
    "name": "provider_agrees",
    "presentable": true,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update field
  collection.fields.addAt(7, new Field({
    "hidden": false,
    "id": "bool1383219978",
    "name": "client_agrees",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  // update field
  collection.fields.addAt(8, new Field({
    "hidden": false,
    "id": "bool1357245225",
    "name": "provider_agrees",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  return app.save(collection)
})
