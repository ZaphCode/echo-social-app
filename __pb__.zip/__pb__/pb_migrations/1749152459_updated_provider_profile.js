/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1868609069")

  // remove field
  collection.fields.removeById("relation3764823788")

  // add field
  collection.fields.addAt(12, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_2726239098",
    "hidden": false,
    "id": "relation1384640224",
    "maxSelect": 3,
    "minSelect": 1,
    "name": "specialtyy",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "relation"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1868609069")

  // add field
  collection.fields.addAt(12, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_3905696460",
    "hidden": false,
    "id": "relation3764823788",
    "maxSelect": 3,
    "minSelect": 1,
    "name": "specialty",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "relation"
  }))

  // remove field
  collection.fields.removeById("relation1384640224")

  return app.save(collection)
})
