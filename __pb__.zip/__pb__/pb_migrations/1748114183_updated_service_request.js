/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update collection data
  unmarshal({
    "viewRule": "@request.auth.id = client || @request.auth.id = service.provider"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update collection data
  unmarshal({
    "viewRule": "(@request.auth.role = \"client\" && @request.auth.id = client) || (@request.auth.role = \"provider\" && @request.auth.id = service.provider)"
  }, collection)

  return app.save(collection)
})
