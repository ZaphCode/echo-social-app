/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // add field
  collection.fields.addAt(3, new Field({
    "cascadeDelete": false,
    "collectionId": "_pb_users_auth_",
    "hidden": false,
    "id": "relation2585760436",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "last_offer_user",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(11, new Field({
    "hidden": false,
    "id": "date3851113217",
    "max": "",
    "min": "",
    "name": "canceled",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "date"
  }))

  // update field
  collection.fields.addAt(7, new Field({
    "hidden": false,
    "id": "select2063623452",
    "maxSelect": 1,
    "name": "agreement_state",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "select",
    "values": [
      "PENDING",
      "ACCEPTED",
      "CANCELED",
      "FINISHED",
      "NEGOTIATION"
    ]
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // remove field
  collection.fields.removeById("relation2585760436")

  // remove field
  collection.fields.removeById("date3851113217")

  // update field
  collection.fields.addAt(5, new Field({
    "hidden": false,
    "id": "select2063623452",
    "maxSelect": 1,
    "name": "request_state",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "select",
    "values": [
      "PENDING",
      "ACCEPTED",
      "CANCELED",
      "FINISHED",
      "NEGOTIATION"
    ]
  }))

  return app.save(collection)
})
