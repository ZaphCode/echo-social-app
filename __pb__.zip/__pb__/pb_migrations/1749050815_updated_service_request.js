/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // remove field
  collection.fields.removeById("bool1383219978")

  // remove field
  collection.fields.removeById("bool1357245225")

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // add field
  collection.fields.addAt(7, new Field({
    "hidden": false,
    "id": "bool1383219978",
    "name": "client_agrees",
    "presentable": true,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  // add field
  collection.fields.addAt(8, new Field({
    "hidden": false,
    "id": "bool1357245225",
    "name": "provider_agrees",
    "presentable": true,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  return app.save(collection)
})
