/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update collection data
  unmarshal({
    "createRule": "@request.auth.id = client.id && @request.auth.id != service.provider"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update collection data
  unmarshal({
    "createRule": "@request.auth.id = client.id"
  }, collection)

  return app.save(collection)
})
