/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update field
  collection.fields.addAt(4, new Field({
    "hidden": false,
    "id": "number3270474448",
    "max": null,
    "min": null,
    "name": "agreed_price",
    "onlyInt": false,
    "presentable": false,
    "required": true,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2589929617")

  // update field
  collection.fields.addAt(4, new Field({
    "hidden": false,
    "id": "number3270474448",
    "max": null,
    "min": null,
    "name": "initial_price",
    "onlyInt": false,
    "presentable": false,
    "required": true,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
})
