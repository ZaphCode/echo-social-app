/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3212041380")

  // update collection data
  unmarshal({
    "updateRule": "@request.auth.id = provider.id"
  }, collection)

  // remove field
  collection.fields.removeById("relation173254826")

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3212041380")

  // update collection data
  unmarshal({
    "updateRule": "@request.auth.id = provider_id.user_id"
  }, collection)

  // add field
  collection.fields.addAt(4, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_1868609069",
    "hidden": false,
    "id": "relation173254826",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "provider_id",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "relation"
  }))

  return app.save(collection)
})
